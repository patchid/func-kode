"use client";

import Image from "next/image";
import Link from "next/link";
import { Poppins } from "next/font/google";
import { OnboardButton } from "@/components/onboard-button";
import { DashboardButton } from "@/components/dashboard-button";
import { LogoutButton } from "@/components/logout-button";
import { createClientComponentClient } from "@supabase/auth-helpers-nextjs";
import type { User } from "@supabase/supabase-js";
import { useEffect, useState } from "react";
import { Menu, X, User as UserIcon, Github, GitFork } from "lucide-react";

const poppins = Poppins({
  subsets: ["latin"],
  weight: ["400", "600", "700", "800"],
  display: "swap",
});

const RELEASE_VERSION = "2026.5.4";

const GITHUB_REPO     = "patchid/func-kode";
const GITHUB_REPO_URL = `https://github.com/${GITHUB_REPO}`;

const NAV_LINKS = [
  { label: "How It Works",          href: "#how-it-works" },
  { label: "For Developers",        href: "#for-developers" },
  { label: "For Teams & Platforms", href: "#for-teams" },
  { label: "The Score",             href: "#the-score" },
  { label: "func(kode)",            href: "/" },
];

/* Exact navItemStyle from ProductLandingPage.tsx */
const navLinkStyle: React.CSSProperties = {
  fontFamily: poppins.style.fontFamily,
  fontSize: "14px",
  fontWeight: 700,
  letterSpacing: "-0.56px",
  color: "#FFFFFF",
  cursor: "pointer",
  transition: "opacity 0.2s ease",
  textDecoration: "none",
  whiteSpace: "nowrap",
};

export function Navbar() {
  const [user,             setUser]             = useState<User | null>(null);
  const [forkCount,        setForkCount]        = useState<number | null>(null);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const supabase = createClientComponentClient();
    supabase.auth.getUser().then(({ data }) => setUser(data.user));
    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user ?? null);
    });
    return () => { listener?.subscription.unsubscribe(); };
  }, []);

  useEffect(() => {
    fetch(`https://api.github.com/repos/${GITHUB_REPO}`, {
      headers: { Accept: "application/vnd.github+json" },
    })
      .then((r) => r.json())
      .then((data) => {
        if (typeof data.forks_count === "number") setForkCount(data.forks_count);
      })
      .catch(() => setForkCount(null));
  }, []);

  const getDisplayName = (u: User) => {
    const gh = u.user_metadata?.user_name || u.user_metadata?.preferred_username;
    if (gh) return `@${gh}`;
    const name = u.user_metadata?.full_name || u.user_metadata?.name;
    if (name) return name;
    if (u.email) return u.email.split("@")[0];
    return "User";
  };

  const closeMobileMenu = () => setIsMobileMenuOpen(false);

  return (
    <>
      {/*
        ── Navbar ──────────────────────────────────────────────
      */}
      <nav
   className="sticky top-0 z-50 w-full"
  style={{
    background: "#040710",
    height: "118px",
  }}
>
  <div
    className="mx-auto flex items-center h-full"
    style={{
      maxWidth: "1440px",
      paddingLeft: "122px",
      paddingRight: "110px",
    }}
  >
        {/* ── LEFT: Logo + version badge ──────────────── */}
        <Link href="/" className="flex items-center gap-5 flex-shrink-0">
          <Image
            src="/logo-dark.svg"
            alt="func(Kode)"
            width={46}
height={46}
className="w-[46px] h-[46px]"
            priority
          />
          {/* Version badge — small rounded rectangle */}
          <span
            title={`Version ${RELEASE_VERSION}`}
            style={{
              fontFamily: poppins.style.fontFamily,
              fontSize: "10px",
              fontWeight: 600,
              letterSpacing: "0",
              color: "rgba(255,255,255,0.45)",
              background: "rgba(255,255,255,0.06)",
              border: "1px solid rgba(255,255,255,0.12)",
              borderRadius: "999px",
              padding: "3px 10px",
              cursor: "default",
              userSelect: "none",
              transition: "opacity 0.2s",
            }}
          >
            {RELEASE_VERSION}
          </span>
        </Link>

        {/* ── CENTER: Desktop nav links — gap: 50px*/}
       <div
  className="hidden lg:flex items-center ml-[95px]"
  style={{ gap: "50px" }}
>
          {NAV_LINKS.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              style={navLinkStyle}
              onMouseEnter={(e) => (e.currentTarget.style.opacity = "0.7")}
              onMouseLeave={(e) => (e.currentTarget.style.opacity = "1")}
            >
              {link.label}
            </Link>
          ))}
        </div>

        {/* ── RIGHT: GitHub forks + Connect ───────────── */}
        <div className="hidden lg:flex items-center ml-auto gap-4">

          {/*
            GitHub forks — NO "Forks" text per user request
            Just: [Github icon] | [GitFork icon] [count]
          */}
          <a
            href={GITHUB_REPO_URL}
            target="_blank"
            rel="noopener noreferrer"
            aria-label="View func(Kode) forks on GitHub"
            className="inline-flex items-center rounded-full overflow-hidden
                       transition-all duration-200 group"
            style={{
              border: "1px solid rgba(255,255,255,0.12)",
              textDecoration: "none",
              fontFamily: poppins.style.fontFamily,
              fontSize: "12px",
              fontWeight: 600,
            }}
          >
            {/* Left: GitHub icon only */}
            <span
              className="flex items-center justify-center px-3 py-2
                         group-hover:bg-white/10 transition-colors"
              style={{ background: "rgba(255,255,255,0.06)", color: "rgba(255,255,255,0.6)" }}
            >
              <Github className="w-3.5 h-3.5" />
            </span>
            {/* Right: fork icon + count */}
            <span
              className="flex items-center gap-1.5 px-3 py-2"
              style={{ background: "rgba(255,255,255,0.1)", color: "#ffffff" }}
            >
              <GitFork className="w-3.5 h-3.5" style={{ color: "#00C9B7" }} />
              {forkCount !== null ? forkCount.toLocaleString() : "—"}
            </span>
          </a>

          {/* Auth state */}
          {user ? (
            <div className="flex items-center gap-2">
              <div
                className="flex items-center gap-2 px-3 py-1.5 rounded-full"
                style={{ border: "1px solid rgba(255,255,255,0.12)", background: "rgba(255,255,255,0.06)" }}
              >
                <UserIcon className="w-3.5 h-3.5" style={{ color: "rgba(255,255,255,0.5)" }} />
                <span
                  className="max-w-28 truncate"
                  style={{ fontFamily: poppins.style.fontFamily, fontSize: "13px", fontWeight: 600, color: "#fff" }}
                >
                  {getDisplayName(user)}
                </span>
              </div>
              <OnboardButton />
              <DashboardButton />
              <LogoutButton />
            </div>
          ) : (
            <Link
              href="/auth/login"
              style={{
                fontFamily: poppins.style.fontFamily,
                fontSize: "14px",
                fontWeight: 700,
                letterSpacing: "-0.42px",
                color: "#000000",
                backgroundColor: "#FFFFFF",
                borderRadius: "40px",
                border: "none",
                width: "85px",
height: "40px",
padding: "0",
                textDecoration: "none",
                display: "inline-flex",
                alignItems: "center",
                justifyContent: "center",
                cursor: "pointer",
                transition: "opacity 0.2s ease",
                whiteSpace: "nowrap",
              }}
              onMouseEnter={(e) => (e.currentTarget.style.opacity = "0.88")}
              onMouseLeave={(e) => (e.currentTarget.style.opacity = "1")}
            >
              Connect
            </Link>
          )}
        </div>

      </div>
        {/* ── MOBILE hamburger ────────────────────────── */}
        <button
          className="lg:hidden p-2 transition-colors"
          style={{ color: "rgba(255,255,255,0.7)" }}
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          aria-label="Toggle menu"
        >
          {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
        </button>
      </nav>

      {/* ── Mobile menu drawer ───────────────────────────────── */}
      {isMobileMenuOpen && (
        <div className="fixed inset-0 z-40 lg:hidden">
          <div
            className="fixed inset-0 animate-in fade-in duration-200"
            style={{ background: "rgba(0,0,0,0.75)", backdropFilter: "blur(6px)" }}
            onClick={closeMobileMenu}
          />
          <div
            className="fixed top-0 right-0 h-full w-80 max-w-[88vw]
                       shadow-2xl animate-in slide-in-from-right duration-300"
            style={{ background: "#040710", borderLeft: "1px solid rgba(255,255,255,0.08)" }}
          >
            {/* Header */}
            <div
              className="flex items-center justify-between px-5 py-4"
              style={{ borderBottom: "1px solid rgba(255,255,255,0.08)" }}
            >
              <div className="flex items-center gap-2">
                <Image src="/logo-dark.svg" alt="func(Kode)" width={36} height={36} className="w-9 h-9" priority />
                <span
                  style={{
                    fontFamily: poppins.style.fontFamily, fontSize: "10px", fontWeight: 600,
                    color: "rgba(255,255,255,0.4)", background: "rgba(255,255,255,0.05)",
                    border: "1px solid rgba(255,255,255,0.1)", borderRadius: "999px",
                    padding: "3px 10px", userSelect: "none",
                  }}
                >
                  {RELEASE_VERSION}
                </span>
              </div>
              <button
                onClick={closeMobileMenu}
                className="p-1.5 rounded-lg transition-colors"
                style={{ color: "rgba(255,255,255,0.5)" }}
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Links */}
            <div className="px-4 py-6 space-y-1">
              {NAV_LINKS.map((link, i) => (
                <Link
                  key={link.href}
                  href={link.href}
                  onClick={closeMobileMenu}
                  className="flex items-center px-4 py-3 rounded-xl
                             transition-all duration-150 active:scale-98
                             animate-in slide-in-from-right duration-200"
                  style={{
                    ...navLinkStyle,
                    color: "rgba(255,255,255,0.6)",
                    animationDelay: `${i * 40}ms`,
                  }}
                  onMouseEnter={(e) => {
                    (e.currentTarget as HTMLElement).style.color = "#fff";
                    (e.currentTarget as HTMLElement).style.background = "rgba(255,255,255,0.05)";
                  }}
                  onMouseLeave={(e) => {
                    (e.currentTarget as HTMLElement).style.color = "rgba(255,255,255,0.6)";
                    (e.currentTarget as HTMLElement).style.background = "transparent";
                  }}
                >
                  {link.label}
                </Link>
              ))}
            </div>

            {/* GitHub forks (mobile) — no text */}
            <div className="px-5 pb-4">
              <a
                href={GITHUB_REPO_URL}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-3 px-4 py-3 rounded-xl transition-all"
                style={{ border: "1px solid rgba(255,255,255,0.08)", background: "rgba(255,255,255,0.03)" }}
              >
                <Github className="w-4 h-4" style={{ color: "rgba(255,255,255,0.5)" }} />
                <span style={{ fontFamily: poppins.style.fontFamily, fontSize: "13px", fontWeight: 600, color: "rgba(255,255,255,0.5)", flex: 1 }}>
                  GitHub Forks
                </span>
                <span className="flex items-center gap-1.5" style={{ fontFamily: poppins.style.fontFamily, fontSize: "13px", fontWeight: 700, color: "#fff" }}>
                  <GitFork className="w-3.5 h-3.5" style={{ color: "#00C9B7" }} />
                  {forkCount !== null ? forkCount.toLocaleString() : "—"}
                </span>
              </a>
            </div>

            {/* Bottom: auth */}
            <div
              className="absolute bottom-0 left-0 right-0 px-5 pb-8 pt-4"
              style={{ borderTop: "1px solid rgba(255,255,255,0.08)" }}
            >
              {user ? (
                <div className="space-y-2">
                  <div
                    className="flex items-center gap-3 px-4 py-3 rounded-xl"
                    style={{ border: "1px solid rgba(255,255,255,0.08)", background: "rgba(255,255,255,0.03)" }}
                  >
                    <div className="w-8 h-8 rounded-full flex items-center justify-center" style={{ background: "linear-gradient(135deg, #00C9B7, #7020BF)" }}>
                      <UserIcon className="w-4 h-4 text-white" />
                    </div>
                    <span style={{ fontFamily: poppins.style.fontFamily, fontSize: "13px", fontWeight: 700, color: "#fff" }}>
                      {getDisplayName(user)}
                    </span>
                  </div>
                  <div onClick={closeMobileMenu}><DashboardButton /></div>
                  <div onClick={closeMobileMenu}><LogoutButton /></div>
                </div>
              ) : (
                <Link
                  href="/auth/login"
                  onClick={closeMobileMenu}
                  className="flex items-center justify-center w-full py-3 rounded-full"
                  style={{
                    fontFamily: poppins.style.fontFamily, fontWeight: 700, fontSize: "14px",
                    letterSpacing: "-0.42px", color: "#000", backgroundColor: "#FFF",
                    textDecoration: "none", transition: "opacity 0.2s",
                  }}
                  onMouseEnter={(e) => (e.currentTarget.style.opacity = "0.88")}
                  onMouseLeave={(e) => (e.currentTarget.style.opacity = "1")}
                >
                  Connect
                </Link>
              )}
            </div>
          </div>
        </div>
      )}
    </>
  )
}